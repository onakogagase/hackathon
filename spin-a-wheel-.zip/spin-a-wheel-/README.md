# Spin A Wheel
Built with [Pha-ser.js](https://phaser.io/)
<p align="center">
<img src="./images/wheel.svg" width="300">
</p>

## Demo-=ttps://dr5hn.github.io/spin-a-wheel

## Follow me at
<a href="https://github.com/dr5hn/"><img alt="Github @dr5hn" src="https://img.shields.io/static/v1?logo=github&message=Github&color=black&style=flat-square&label=" /></a> <a href="https://twitter.com/dr5hn/"><img alt="Twitter @dr5hn" src="https://img.shields.io/static/v1?logo=twitter&message=Twitter&color=black&style=flat-square&label=" /></a> <a href="https://www.linkedin.com/in/dr5hn/"><img alt="LinkedIn @dr5hn" src="https://img.shields.io/static/v1?logo=linkedin&message=LinkedIn&color=black&style=flat-square&label=&link=https://twitter.com/dr5hn" /></a>

## Contributions / Suggestions / Feedbacks
```
Contributions, Suggestions & Feedbacks are Most Welcome
Get in touch with me at gadadarshan[at]gmail[dot]com
```

That's all Folks !! Enjoy.
